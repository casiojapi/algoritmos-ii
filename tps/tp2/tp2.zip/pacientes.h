#ifndef PACIENTES_H
#define PACIENTES_H
#include "hash.h"
#include "abb.h"

//Struct y funciones Pacientes
typedef struct paciente paciente_t;
typedef hash_t pacientes_t;

void paciente_destruir(void *dato);
void *paciente_constructor(char** campos, void* extra);

pacientes_t *pacientes_crear(const char* ruta_csv);
paciente_t* pacientes_obtener(pacientes_t* pacientes, char* nombre_paciente);
bool pacientes_pertenece(pacientes_t* pacientes, char* nombre_paciente);
void pacientes_destruir(pacientes_t *pacientes);

int cmp_anios_paciente(const void* p1, const void* p2);

#endif
