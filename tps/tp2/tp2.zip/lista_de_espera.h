#ifndef LISTA_DE_ESPERA_H
#define LISTA_DE_ESPERA_H

#include <stdbool.h>
#include "heap.h"
//typedef int (*cmp_func_t)(const void *a, const void *b);

typedef struct lista_esp lista_esp_t;
typedef void (*destruir_dato_t)(void *);

lista_esp_t* lista_esp_crear(cmp_func_t cmp);

size_t lista_esp_cantidad(lista_esp_t* lista_esp);
bool lista_esp_turno_urgente(lista_esp_t* lista_esp, void* paciente);

bool lista_esp_turno_regular(lista_esp_t* lista_esp, void* paciente);

void lista_esp_destruir(void* lista);


void* lista_esp_siguiente(lista_esp_t* lista_esp);

typedef hash_t especialidades_t;

especialidades_t* especialidades_crear();

void especialidades_destruir(especialidades_t* especialidades);
bool especialidades_pertenece(especialidades_t* especialidades, char* especialidad);
bool especialidades_guardar(especialidades_t* especialidades, char* especialidad, void* dato);
void* especialidades_obtener(especialidades_t* especialidades, char* especialidad);

#endif 
