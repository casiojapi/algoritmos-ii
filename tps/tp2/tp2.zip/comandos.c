#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// #include "funciones_tp2.h"
#include "pacientes.h"
#include "doctores.h"
#include "lista_de_espera.h"
#include "comandos.h"
#include "mensajes.h"
#include "hash.h"


//Funciones
//Pedir turno

void pedir_turno(pacientes_t *pacientes, doctores_t *doctores, especialidades_t* listas_de_espera, char* nombre_paciente, char* especialidad, char* urgencia) {
    // paciente_t *paciente = paciente_obtener(pacientes, nombre_paciente);
    bool ok = true;
    if (!pacientes_pertenece(pacientes, nombre_paciente)) {
        printf(ENOENT_PACIENTE, nombre_paciente);
        ok = false;
    }
    if (!doctores_pertenece_especialidad(doctores, especialidad)) {
        printf(ENOENT_ESPECIALIDAD, especialidad);
        ok = false;
    }
    if ((strcmp("URGENTE", urgencia) || !strcmp("REGULAR", urgencia)) && (!strcmp("URGENTE", urgencia) || strcmp("REGULAR", urgencia))) {
        printf(ENOENT_URGENCIA, urgencia);
        ok = false;
    }
    if (ok) {
        if (!especialidades_pertenece(listas_de_espera, especialidad)) {
            lista_esp_t* nueva_lista = lista_esp_crear(cmp_anios_paciente);
            if (nueva_lista == NULL) return;
            especialidades_guardar(listas_de_espera, especialidad, nueva_lista);
        }

        lista_esp_t* lista_de_espera_actual = especialidades_obtener(listas_de_espera, especialidad);

        if (!strcmp("URGENTE", urgencia))
            lista_esp_turno_urgente(lista_de_espera_actual, nombre_paciente);
        else if (!strcmp("REGULAR", urgencia))
            lista_esp_turno_regular(lista_de_espera_actual, nombre_paciente);

        size_t cant_actual = lista_esp_cantidad(lista_de_espera_actual);
        printf(PACIENTE_ENCOLADO, nombre_paciente);
        printf(CANT_PACIENTES_ENCOLADOS, cant_actual, especialidad);
    }
}

// Atender siguiente
void atender_siguiente(doctores_t* doctores, char* nombre_doctor) {
    bool ok = true;
    doctor_t* doctor = doctores_buscar(doctores, nombre_doctor);
    if (!doctor) {
        printf(ENOENT_DOCTOR, nombre_doctor);
        ok = false;
    }
    if (ok) {
        char* especialidad = doctor_especialidad(doctor);
        lista_esp_t* lista_de_espera = doctores_obtener_dato_especialidad(doctores, especialidad);
        char* paciente = lista_esp_siguiente(lista_de_espera);
        if (paciente == NULL) {
            printf(SIN_PACIENTES);
            return;
        }
        printf(PACIENTE_ATENDIDO, paciente);
        size_t cant_actual = lista_esp_cantidad(lista_de_espera);
        printf(CANT_PACIENTES_ENCOLADOS, cant_actual, nombre_doctor);
        doctor_sumar_atendido(doctor);
    }
}


void informe_doctores(doctores_t* doctores, char* inicio, char* fin) {
    if (!strcmp(inicio, "")) inicio = NULL;
    if (!strcmp(fin, "")) fin = NULL;
    abb_iter_t* iter = abb_iter_in_crear(doctores_obtener_abb(doctores));

    size_t n_docs = 1;

    printf(DOCTORES_SISTEMA, doctores_cantidad(doctores));

    while (inicio && !abb_iter_in_al_final(iter)) {
        doctor_t* doc = abb_iter_in_ver_actual(iter);
        if (!strcmp(doctor_nombre(doc), inicio)) break;
    }

    while (!abb_iter_in_al_final(iter)) {
        doctor_t* doc = abb_iter_in_ver_actual(iter);
        printf(INFORME_DOCTOR, n_docs, doctor_nombre(doc), doctor_especialidad(doc), doctor_cant_atendidos(doc));
        n_docs++;
        if (!strcmp(fin, doctor_nombre(doc))) break;
        abb_iter_in_avanzar(iter);
    }
    abb_iter_in_destruir(iter);
}
