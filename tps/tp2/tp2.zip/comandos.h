#ifndef COMANDOS_H
#define COMANDOS_H

#include "lista_de_espera.h"

void pedir_turno(pacientes_t* pacientes, doctores_t* doctores, especialidades_t* listas_de_espera, char* nombre_paciente, char* especialidad, char* urgencia);

void atender_siguiente(doctores_t* doctores, char* nombre_doctor);

void informe_doctores(doctores_t* doctores, char* inicio, char* fin);

#endif
